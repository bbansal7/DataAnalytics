data <- read.csv("clipboard", sep= ";", header=T)
class(data)
library(arules)
sum(is.na(data))

data <- data[ , -c(6,13:16)]
str(data)
data$duration <- factor(ifelse(data$duration >= 0,"Yes", "No" ) )             

final_data <- as.data.frame(unclass(data), stringsAsFactors = TRUE)
final_data <- as(final_data, "transactions")
rules <- apriori(final_data)
rules <- apriori(final_data, parameter = list(maxlen=6, supp= 0.01, conf = 0.28), appearance = list(rhs ="y=yes", default = "lhs"))
inspect(rules)
