
## read the data into R - DATASET_2
data <- read.csv ("bank-full.csv", sep = ";", header = T)

# customer life time value - how much contributions they made to customer
# Want to see that hgh value customers - patterns 
# 

## check the missing values in the data 
sum(is.na(data))

# I don't like col name y - rename to deposit
colnames(data)
names(data)[names(data) == "y"] <- "deposit"
# move the deposit to the front - for easy debugging
data <- data %>% relocate("deposit", .after="age")


### clean the data columns since it contains unnecessary spaces
install.packages ("janitor")
library(janitor)
data <- clean_names(data)

data_safe <-data


# Let us make Age as categorical 
minage <-min(data$age)
maxage <-max(data$age)
minage
maxage

# 
# Categories are
# 18-30  - noKids
# 30-45  - babyParents
# 45- 60 - CollegeKidsParents
# 60 -80 - SrCitizens
# 80 -95 - SuperSrCitizens
# 
# Reclassify and age Age a categorical value

data$age <- cut(data$age, 
                breaks=c(minage,36,1,461, 81, Inf), 
                labels=c('noKids','babyParents','CollegeParents', 
                         'SrCitizens', 'SuperSrCitizens'),
                include.lowest = TRUE)
table(data$age)

# let us categorize the balance - in case it helps
min_balance <-min(data$balance)
max_balance <-max(data$balance)
min_balance
max_balance

# Let us categorize as 
# -ve values to - NegativeBalance
# 0-5k - lowBalance
# 5k-11k - highBalance

data$balance <- cut(data$balance,
                breaks=c(min_balance,0,5000,Inf), 
                labels=c('NegavtiveBal','lowBalance','highBalance'),
                include.lowest = TRUE)

table(data$balance)

# Let us categorize the day of the week they were contacted
# 1- monday
# ... 5 is Fri

data$day <- cut(data$day,
                    breaks=c(0,1,2,3,4,Inf), 
                    labels=c('Mon','Tue','Wed', 'Thu', 'Fri'),
                    include.lowest = TRUE)

#
# Let us categorize the last contact month into a categorical variable
# Let us do this as QTR
# Jan-Apr - Q1 ... Oct-Dec  - Q4


month.abb
monthAbbLower <- tolower(month.abb)
monthAbbLower
data$month = match(data$month,monthAbbLower)
table(data$month)

data$qtr <- cut(data$month,
                breaks=c(1,4,7,10,Inf), 
                labels=c('Q1','Q2','Q3', 'Q4'),
                include.lowest = TRUE)
table(data$qtr)

#data$qtr <- factor(ifelse((data$month == "jan" || data$month == "feb"|| data$month == "mar")),
#                   "Q1",
#                   ifelse((data$month == "apr" || data$month == "may"|| data$month == "jun")), 
#                   "Q2", 
#                   ifelse( (data$month == "jul" || data$month == "aug" || data$month == "sep"), 
#                           "Q3",  "Q4") )
#table(data$qtr)

# Categorize pdays 
min_pdays <-min(data$pdays)
max_pdays <-max(data$pdays)
min_pdays
max_pdays
table (data$pdays)
# I am assuming -1 is never contacted instead of 999 as per the text doc
# Categories are 
# <0 - notContacted
# 1-180 - Within6m
# 180-365- Between6mTo1y
# 365-730 - Between1yTo2y
# 730+ - Between2yTo3y

data$pdays <- cut(data$pdays,
                    breaks=c(min_pdays,0,180,365, 730, Inf), 
                    labels=c('NotContacted','Within6m','Bet6mTo1y', 
                             "Bet1yTo2y", "Bet2yTo3y"),
                    include.lowest = TRUE)
table(data$pdays)

# Categorize previous number of contacts 
min_previous <-min(data$previous)
max_previous <-max(data$previous)
min_previous
max_previous
table (data$previous)

# 
# Categories are 
# 0 - noContacts
# 1-10  - lowContacts
# 10-30 - medContacts
# 30-50 - HighContacts
# 50+ - VeryHighContacts

data$previous <- cut(data$previous,
                  breaks=c(0,5,10,30, 50, Inf), 
                  labels=c('VeyLowContacts','LowContacts','MedContacts', 
                           "HighContacts", "VeryHighContacts"),
                  include.lowest = TRUE)
table (data$previous)



# Categorize duration of contact
min_duration <-min(data$duration)
max_duration <-max(data$duration)
min_duration
max_duration
table (data$duration)

# Let use percentile or this and split to 3 categories - LowDuration, Med and High

percentile_33 <- quantile(data$duration, prob = .3333)
percentile_66 <- quantile(data$duration, prob = .6666)
percentile_33
percentile_66

data$duration <- cut(data$duration,
                     breaks=c(min_duration,percentile_33,percentile_66,Inf),
                     labels=c('LowDuration','MediumDuration','HighDuration'),
                     include.lowest = TRUE)


table (data$duration)

str(data)

#factorize all other fields
data$job <- factor(data$job)
table(data$job)

data$marital <- factor(data$marital)
table(data$marital)

data$education  <- factor(data$education)
table(data$education)


data$housing <- factor(ifelse (data$housing == "yes", "housing_yes", "housing_no"))
table(data$housing)

data$loan <- factor(ifelse (data$loan == "yes", "loan_yes", "loan_no"))
table(data$loan)

data$default <- factor(ifelse (data$default == "yes", "crDefault_yes", "crDefault_no"))
table(data$default)

data$contact <- factor(data$contact)
table(data$contact)

table(data$campaign)
# too many campaigns- can we reduce it 
# From table we see 1-10 have good numbers - keep that as C1-c10
# then we can club 10-20, 21-30, 30-inf  as C11-20, C21-30, C31above
data$campaign <- cut(data$campaign,
                     breaks=c( 0,1,2,3,4,5,6,7,8,9,10,20,30,Inf),
                     labels=c('C1','C2','C3','C4','C5',
                              'C6','C7','C8','C9','C10',
                              'C11-20','C21-30','C31Above'),
                     include.lowest = TRUE)
table(data$campaign)


data$poutcome <- factor(data$poutcome)
table(data$poutcome)

data$deposit <- factor(ifelse (data$deposit == "yes", "termDeposit_yes", "termDeposit_no"))
table(data$deposit)
str(data)

# delete some unnecessary columns 
# There is nothing to delete. Keep all cols
final_data <- subset(data, select = -c(contact, month )) # we use qtr instead of month

# All should be categorical now 
str(final_data)

### print the summary of the final_data
summary(final_data)
write.csv(final_data, "final_bank_data.csv")


###
library(arules)

final_data <- as(final_data, "transactions")
# Transactions - this is formatted to comma separated 

summary(final_data)
#> summary(final_data)
#transactions as itemMatrix in sparse format with
#45211 rows (elements/itemsets/transactions) and
#74 columns (items) and a density of 0.2162162 
#
#most frequent items:
#  default=crDefault_no previous=VeyLowContacts                 day=Fri  deposit=termDeposit_no            loan=loan_no 
#44396                   44147                   41072                   39922                   37967 
#(Other) 
#515872 


str(final_data)
# inspect(final_data)
final_data@itemInfo[["labels"]]
label <- final_data@itemInfo["labels"]


##### want to print the association of deposits
rules <- apriori(final_data, 
                      parameter = list(supp=0.01, conf = 0.51, 
                                       minlen = 6, maxlen = 14), 
                      appearance =list(default = "lhs", rhs = "deposit=termDeposit_yes"))

inspect(rules)
redundant <- is.redundant(rules, measure="confidence")
which(redundant)
rules.pruned <- rules[!redundant]
inspect(rules.pruned)
rules.pruned <- sort(rules.pruned, by="lift")
inspect(rules.pruned)

conf_rules<- sort(rules , by ="lift", decreasing = T )
rules2 <- inspect(conf_rules[1:11], linebreak = FALSE)

write.csv(rules2, "bank_deposit_customers.csv")

itemFrequencyPlot(final_data, topN=15)
# itemFrequencyPlot(final_data, type ="relative")



########################## end ###############################




########## extract the rules for customers with low_clv
rules_low <- apriori(final_data, parameter = list(supp=0.02, conf = 0.71, maxlen = 6), 
                     appearance =list(default = "lhs", 
                                      rhs="customer_lifetime_value=low_clv"))

conf_rules_low<- sort(rules_low , by ="lift", decreasing = T )
rules_low <- inspect(conf_rules_low[1:3], linebreak = FALSE)

write.csv(rules_low, "low_CLV_customers.csv")

####### extract the rules for customer with medium_clv

rules_medium <- apriori(final_data, parameter = list(supp=0.06, conf = 0.80, maxlen = 6), 
                        appearance =list(default = "lhs", 
                                         rhs="customer_lifetime_value=medium_clv"))
inspect(rules_medium)
conf_rules_medium<- sort(rules_medium , by ="lift", decreasing = T )
medium_clv <- inspect(conf_rules_medium[1:10], linebreak = FALSE)
write.csv(medium_clv, "medium_CLV_customers.csv")

itemFrequencyPlot(final_data, topN=15)
# itemFrequencyPlot(final_data, type ="relative")

